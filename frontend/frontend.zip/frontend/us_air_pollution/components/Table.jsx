import { Box, useTheme } from "@mui/material";
import { tokens } from "../theme";
import { DataGrid } from "@mui/x-data-grid";

const Basic_Table = ({ columns, rows }) => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);

    return (
        <Box
            width="100%"
            m="20px 0 0 0"
            height="75vh"
            sx={{
                "& .MuiDataGrid-root": {
                    border: "none",
                },
                "& .MuiDataGrid-cell": {
                    borderBottom: "none",
                    padding: '3px', // Reduced padding for a more compact look
                },
                "& .MuiDataGrid-columnHeaders": {
                    backgroundColor: colors.blueAccent[700],
                    borderBottom: "none",
                },
                "& .MuiDataGrid-virtualScroller": {
                    backgroundColor: colors.primary[400],
                },
                "& .MuiDataGrid-footerContainer": {
                    borderTop: "none",
                    backgroundColor: colors.blueAccent[700],
                },
                "& .MuiCheckbox-root": {
                    color: `${colors.greenAccent[200]} !important`,
                },
                "& .MuiDataGrid-row": {
                    minHeight: '20px', // Reduce row height
                },
            }}
        >
            <DataGrid
                checkboxSelection
                rows={rows}
                columns={columns}
                rowHeight={30} // Set a smaller row height
                headerHeight={30} // Optionally, reduce the header height
                autoWidth={true} // Enable auto width for columns
                getRowId={(row) => row.id}
            />
        </Box>
    );
}

export default Basic_Table;
