function MapVisualizations() {
    return (
        <div>
            <h1>Top 15 Worst AQI Recordings</h1>
        </div>
    );
  }
  
  export default MapVisualizations;