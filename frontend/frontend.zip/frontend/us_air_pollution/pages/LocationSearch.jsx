import React, { useState, useEffect } from 'react';
import { Box, TextField, Button, Select, MenuItem, InputLabel, FormControl, Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@mui/material';
import Header from '../components/Header';
import Basic_Table from '../components/Table';

const generateColumns = (data) => {
    if (data && data.length > 0) {
      return Object.keys(data[0])
        .filter(key => key !== 'max_hour' && key !== 'site_id' && key !== 'id') // Exclude 'max_hour' and 'site_id'
        .map(key => ({
          field: key,
          headerName: key.toUpperCase(),
          width: 120,
        }));
    }
    return [];
  };
  

const LocationSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [regionType, setRegionType] = useState('');
  const [siteId, setSiteId] = useState(''); // State for site ID
  const [data, setData] = useState([]);

  const [columns, setColumns] = useState([]);

  const [siteAverage, setSiteAverage] = useState(null);
  const [loadingSiteAverage, setLoadingSiteAverage] = useState(false);

  const fetchSiteAverage = (siteId) => {
    setLoadingSiteAverage(true);
    fetch(`http://127.0.0.1:5000/api/site_average/?site_id=${searchTerm}`) // Use siteId from the argument
      .then(response => response.json())
      .then(avgData => {
        // Assuming the response is an array with one object
        if (avgData.length > 0) {
          setSiteAverage(avgData[0]); // Store the first object of the array
        }
        setLoadingSiteAverage(false);
      })
      .catch(error => {
        console.error('Error fetching site average:', error);
        setLoadingSiteAverage(false);
      });
  };
  


  useEffect(() => {
    // Generate columns whenever data changes
    setColumns(generateColumns(data));
  }, [data]);

  const handleSearch = () => {
    if (regionType === 'site_id') {
      console.log(`Searching for site ID ${searchTerm}`);
      fetch(`http://127.0.0.1:5000/api/getdata/?site_id=${searchTerm}`)
        .then(response => response.json())
        .then(data => setData(data))
        .catch(error => console.error('Error:', error));
        console.log(data);
    } else {
      // Handle other region types
    }
  };

  return (
    <Box m="20px">
        <Header title="Location Search" subtitle="Search Pollution Records by Location" />

        <Box height="66vh" border="0px solid #ddd" borderRadius="4px" p="0px">
            <Box display="flex" gap="10px" mb="0px" alignItems="center">
                {/* Input fields and buttons */}
                <TextField
                    label="Search Location"
                    variant="outlined"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <FormControl sx={{ width: '200px' }}>
                    <InputLabel>Region Type</InputLabel>
                    <Select
                        value={regionType}
                        label="Region Type"
                        onChange={(e) => setRegionType(e.target.value)}
                    >
                        <MenuItem value="city">City</MenuItem>
                        <MenuItem value="county">County</MenuItem>
                        <MenuItem value="state">State</MenuItem>
                        <MenuItem value="site_id">Site ID</MenuItem>
                    </Select>
                </FormControl>
                <Button variant="contained" color="secondary" onClick={handleSearch}>Search</Button>
                <Button variant="contained" color="secondary" onClick={fetchSiteAverage}>Site Average</Button>

                {/* Site Average Display */}
                {loadingSiteAverage ? (
                    <Typography>Loading site average...</Typography>
                ) : (
                    siteAverage && (
                        <Box ml={2}>
                            <Typography style={{ color: 'white', fontWeight: 'bold', fontSize: 'larger' }}>
                                Site Average Mean: {siteAverage.avg_mean}, Average AQI: {siteAverage.avg_aqi}
                            </Typography>
                        </Box>
                    )
                )}
            </Box>

            {/* Table */}
            <Box mb="20px">
                <Basic_Table columns={columns} rows={data} />
            </Box>
        </Box>
    </Box>
);
};

export default LocationSearch;
