import React, { useState, useEffect } from 'react';
import { Box, TextField, Button, FormControl, Typography, Slider, FormControlLabel, Checkbox } from '@mui/material';
import Header from '../components/Header';
import Basic_Table from '../components/Table';

const generateColumns = (data) => {
    if (data && data.length > 0) {
      return Object.keys(data[0])
        .map(key => ({
          field: key,
          headerName: key.toUpperCase(),
          width: 120,
        }));
    }
    return [];
  };


function AdvancedSearch() {
  const [searchParams, setSearchParams] = useState({
    compound_id: '',
    site_id: '',
    date: '',
    start_date: '',
    end_date: '',
    mean: '',
    gte_mean: '',
    lte_mean: '',
    aqi: '',
    gte_aqi: '',
    lte_aqi: ''
  });
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);

  useEffect(() => {
    setColumns(generateColumns(data));
  }, [data]);

  const [rangeValues, setRangeValues] = useState({
    mean: [0, 100], // Example range, adjust according to your data
    aqi: [0, 500], // Example range
  });


  const [useRange, setUseRange] = useState({
    date: false,
    mean: false,
    aqi: false,
  });

  
  const handleSearch = () => {
    let modifiedParams = { ...searchParams };

    // Update params for ranges
    if (useRange.mean) {
      modifiedParams.gte_mean = rangeValues.mean[0];
      modifiedParams.lte_mean = rangeValues.mean[1];
      delete modifiedParams.mean; // Remove the direct mean field
    }
    // Similar checks for 'aqi' and other range fields

  // Remove any empty or null values
  Object.keys(modifiedParams).forEach(key => {
    if (modifiedParams[key] === '' || modifiedParams[key] === null) {
      delete modifiedParams[key];
    }
  });

  // Create query string
  const queryParams = new URLSearchParams(modifiedParams).toString();
  console.log(queryParams); // Log to verify the query string

  fetch(`http://127.0.0.1:5000/api/getdata/?${queryParams}`)
    .then(response => response.json())
    .then(data => setData(data))
    .catch(error => console.error('Error:', error));
    };
  

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSearchParams(prevParams => ({
      ...prevParams,
      [name]: value
    }));
};

  return (
    <Box m="20px">
      <Header title="Advanced Search" subtitle="Search Detailed Pollution Records" />

      <Box>
        <Box display="flex" flexWrap="wrap" gap="10px" mb="20px">
          {/* Compound ID */}
          <TextField 
            label="Compound ID" 
            name="compound_id" 
            value={searchParams.compound_id} 
            onChange={handleInputChange} 
          />

          {/* Site ID */}
          <TextField 
            label="Site ID" 
            name="site_id" 
            value={searchParams.site_id} 
            onChange={handleInputChange} 
          />

          {/* Date */}
          <TextField 
            label="Date" 
            type="date"
            InputLabelProps={{ shrink: true }}
            name="date" 
            value={searchParams.date} 
            onChange={handleInputChange} 
          />

          {/* Start Date */}
          <TextField 
            label="Start Date" 
            type="date"
            InputLabelProps={{ shrink: true }}
            name="start_date" 
            value={searchParams.start_date} 
            onChange={handleInputChange} 
          />

          {/* End Date */}
          <TextField 
            label="End Date" 
            type="date"
            InputLabelProps={{ shrink: true }}
            name="end_date" 
            value={searchParams.end_date} 
            onChange={handleInputChange} 
          />

          {/* Mean */}
          <TextField 
            label="Mean" 
            name="mean" 
            value={searchParams.mean} 
            onChange={handleInputChange} 
          />

          {/* Greater Than or Equal Mean */}
          <TextField 
            label="Greater Than or Equal Mean" 
            name="gte_mean" 
            value={searchParams.gte_mean} 
            onChange={handleInputChange} 
          />

          {/* Less Than or Equal Mean */}
          <TextField 
            label="Less Than or Equal Mean" 
            name="lte_mean" 
            value={searchParams.lte_mean} 
            onChange={handleInputChange} 
          />

          {/* AQI */}
          <TextField 
            label="AQI" 
            name="aqi" 
            value={searchParams.aqi} 
            onChange={handleInputChange} 
          />

          {/* Greater Than or Equal AQI */}
          <TextField 
            label="Greater Than or Equal AQI" 
            name="gte_aqi" 
            value={searchParams.gte_aqi} 
            onChange={handleInputChange} 
          />

          {/* Less Than or Equal AQI */}
          <TextField 
            label="Less Than or Equal AQI" 
            name="lte_aqi" 
            value={searchParams.lte_aqi} 
            onChange={handleInputChange} 
          />

          <Button variant="contained" color="secondary" onClick={handleSearch}>
            Search
          </Button>
        </Box>

        <Basic_Table columns={columns} rows={data} />
      </Box>
    </Box>
  );
}

export default AdvancedSearch;