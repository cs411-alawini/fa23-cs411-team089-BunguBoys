import React from 'react';
import { Card, CardContent, Typography, CardActionArea, Box } from '@mui/material';
import { LocationOn, AccessTime, Search, Edit, Map } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';

function Landing() {
  const navigate = useNavigate();

  const cards = [
    { title: 'Location Search', icon: <LocationOn style={{ fontSize: 24, color: 'black' }} />, path: '/location' },
    { title: 'Time Frame Search', icon: <AccessTime style={{ fontSize: 24, color: 'black' }} />, path: '/time' },
    { title: 'Advanced Search', icon: <Search style={{ fontSize: 24, color: 'black' }} />, path: '/advanced' },
    { title: 'CRUD', icon: <Edit style={{ fontSize: 24, color: 'black' }} />, path: '/crud' },
    { title: 'Map Visualizations', icon: <Map style={{ fontSize: 24, color: 'black' }} />, path: '/map' },
  ];

  return (
    <Box  m="20px">
      {/* Page Header */}
      <Header title="Home" subtitle="Explore Pollution Data" />

      {/* Card Grid */}
      <Box display="grid" gridTemplateColumns="repeat(3, 1fr)" gap={2}>
        {cards.map((card, index) => (
          <Card key={index} sx={{ maxWidth: 345, cursor: 'pointer', backgroundColor: 'white' }} onClick={() => navigate(card.path)}>
            <CardActionArea>
              <CardContent sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography gutterBottom variant="h5" component="div" sx={{ fontSize: '1.5rem', color: 'black' }}>
                  {card.title}
                </Typography>
                {card.icon}
              </CardContent>
            </CardActionArea>
          </Card>
        ))}
      </Box>
    </Box>
  );
}

export default Landing;
