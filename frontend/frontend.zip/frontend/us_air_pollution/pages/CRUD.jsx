import React, { useState } from 'react';
import { Box, Accordion, AccordionSummary, AccordionDetails, Typography, Button, TextField } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Header from '../components/Header';
import Basic_Table from '../components/Table';
import toast from 'react-hot-toast';

const generateColumns = (data) => {
    if (data && data.length > 0) {
        return Object.keys(data[0])
            .map(key => ({
                field: key,
                headerName: key.toUpperCase(),
                width: key === 'id' ? 70 : 120, // Adjust width for the 'id' column
            }));
    }
    return [];
};



  
  function CRUD() {
      const [measurementData, setMeasurementData] = useState({
          site_id: '',
          compound_id: '',
          date: '',
          parts_per: '',
          mean: '',
          max_value: '',
          max_hour: '',
          aqi: ''
      });
      const [readId, setReadId] = useState(''); // State to store the ID for read operation
      const [deleteID, setDeleteId] = useState(''); // State to store the ID for delete operation
      const [updateId, setUpdateId] = useState(''); // State to store the ID for update operation
      const [tableData, setTableData] = useState([]); // State to store the fetched data for the table
      const [tableColumns, setTableColumns] = useState([]); // State to store the columns for the table

  
      const handleInputChange = (e, field) => {
          setMeasurementData(prev => ({ ...prev, [field]: e.target.value }));
      };
  
      const handleCreateMeasurement = () => {
        console.log('Sending data:', measurementData);
        fetch('http://127.0.0.1:5000/api/measurement/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(measurementData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json(); // Only parse as JSON if response is OK
        })
        .then(data => {
            toast.success('Successfully created measurement!')
            console.log('Success:', data);
        })
        .catch((error) => {
            console.error('Error:', error);
            toast.error('Error creating measurement');
        });
    };    
    

      const handleReadMeasurement = () => {
        fetch(`http://127.0.0.1:5000/api/measurement/${readId}`)
            .then(response => response.json())
            .then(data => {
                // Assuming the response is a single object wrapped in an array
                const formattedData = Array.isArray(data) ? data : [data];
    
                // Check if the data has an 'id' field
                if (formattedData.length > 0 && !formattedData[0].hasOwnProperty('id')) {
                    console.error('Data does not have an id property:', formattedData);
                    return;
                }
    
                setTableData(formattedData);
                setTableColumns(generateColumns(formattedData));
                toast.success('Successfully read measurement!')
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    };
    

    const handleUpdateMeasurement = () => {
        fetch(`http://127.0.0.1:5000/api/measurement/${updateId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(measurementData)
        })
        .then(response => response.json())
        .then(data => {
            console.log('Update Success:', data);
            toast.success('Successfully updated measurement!')
            // Optionally refresh data or provide user feedback
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    };
    

    const handleDeleteMeasurement = () => {
        fetch(`http://127.0.0.1:5000/api/measurement/${deleteID}`, { // Use appropriate ID
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            console.log('Delete Success:', data);
            toast.success('Successfully deleted measurement!')
            // Optionally refresh data or provide user feedback
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    };
    


  
      // Render CRUD operations for Measurement
      const renderMeasurementCRUD = () => {
          return (
              <Box>
                  <Typography variant="h3" mb="10px">Create Measurement</Typography>
                    <Box display="flex" gap="10px" mb="10px" flexDirection="row">
                        {/* Add TextField for each column */}
                            <TextField label="Site ID" variant="outlined" value={measurementData.site_id} onChange={(e) => handleInputChange(e, 'site_id')} />
                            <TextField label="Compound ID" variant="outlined" value={measurementData.compound_id} onChange={(e) => handleInputChange(e, 'compound_id')} />
                            <TextField label="Date" variant="outlined" value={measurementData.date} onChange={(e) => handleInputChange(e, 'date')} />
                            <TextField label="Parts Per" variant="outlined" value={measurementData.parts_per} onChange={(e) => handleInputChange(e, 'parts_per')} />
                            <TextField label="Mean" variant="outlined" value={measurementData.mean} onChange={(e) => handleInputChange(e, 'mean')} />
                            <TextField label="Max Value" variant="outlined" value={measurementData.max_value} onChange={(e) => handleInputChange(e, 'max_value')} />
                            <TextField label="Max Hour" variant="outlined" value={measurementData.max_hour} onChange={(e) => handleInputChange(e, 'max_hour')} />
                            <TextField label="AQI" variant="outlined" value={measurementData.aqi} onChange={(e) => handleInputChange(e, 'aqi')} />
                        {/* ... TextFields for each measurementData field ... */} 
                        {/* Create button */}     
                        <Button variant="contained" color="secondary" onClick={handleCreateMeasurement}>Create</Button>
                    </Box>

                    {/* Read Operation */}
                  <Typography variant="h3" mb="10px">Read Measurement</Typography>
                    <Box display="flex" gap="10px" mb="10px" flexDirection="row">
                        <TextField 
                            label="Measurement ID" 
                            value={readId} 
                            onChange={(e) => setReadId(e.target.value)} 
                        />
                        <Button variant="contained" color="secondary" onClick={handleReadMeasurement}>Read</Button>
                    </Box>
                
                    {/* Update Operation */}
                <Typography variant="h3" mb="10px">Update Measurement</Typography>
                    <Box display="flex" gap="10px" mb="10px" flexDirection="row">
                        {/* Add TextField for each column */}
                        <TextField 
                            label="Measurement ID" 
                            value={updateId} 
                            onChange={(e) => setUpdateId(e.target.value)} 
                        />
                        <TextField label="Site ID" variant="outlined" value={measurementData.site_id} onChange={(e) => handleInputChange(e, 'site_id')} />
                        <TextField label="Compound ID" variant="outlined" value={measurementData.compound_id} onChange={(e) => handleInputChange(e, 'compound_id')} />
                        <TextField label="Date" variant="outlined" value={measurementData.date} onChange={(e) => handleInputChange(e, 'date')} />
                        <TextField label="Parts Per" variant="outlined" value={measurementData.parts_per} onChange={(e) => handleInputChange(e, 'parts_per')} />
                        <TextField label="Mean" variant="outlined" value={measurementData.mean} onChange={(e) => handleInputChange(e, 'mean')} />
                        <TextField label="Max Value" variant="outlined" value={measurementData.max_value} onChange={(e) => handleInputChange(e, 'max_value')} />
                        <TextField label="Max Hour" variant="outlined" value={measurementData.max_hour} onChange={(e) => handleInputChange(e, 'max_hour')} />
                        <TextField label="AQI" variant="outlined" value={measurementData.aqi} onChange={(e) => handleInputChange(e, 'aqi')} />
                        {/* ... TextFields for each measurementData field ... */}
                        {/* Update button */}
                        <Button variant="contained" color="secondary" onClick={handleUpdateMeasurement}>Update</Button>
                    </Box>

                {/* Delete Operation */}
                <Typography variant="h3" mb="10px">Delete Measurement</Typography>
                    <Box display="flex" gap="10px" mb="10px" flexDirection="row">
                        <TextField 
                                label="Measurement ID" 
                                value={deleteID} 
                                onChange={(e) => setDeleteId(e.target.value)} 
                            />
                        <Button variant="contained" color="secondary" onClick={handleDeleteMeasurement}>Delete</Button>
                    </Box>

                
                <Basic_Table columns={tableColumns} rows={tableData} />
                  
  

              </Box>
          );
      };
  
      return (
          <div>
              <Header title="CRUD Operations for Measurement" subtitle="Manage Measurement Table" />
              <Accordion>
                  <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography>Measurement</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                      {renderMeasurementCRUD()}
                  </AccordionDetails>
              </Accordion>
          </div>
      );
  }
  
  export default CRUD;
  