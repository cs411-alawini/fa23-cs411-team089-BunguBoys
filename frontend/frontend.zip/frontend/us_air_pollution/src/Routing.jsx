import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Landing from '/pages/Landing';
import About from '/pages/About';
import LocationSearch from '/pages/LocationSearch'; // Assuming this is the component for Location Search
import TimeFrameSearch from '/pages/TimeFrameSearch'; // Assuming this is the component for Time Frame Search
import AdvancedSearch from '/pages/AdvancedSearch'; // Assuming this is the component for Advanced Search
import CRUD from '/pages/CRUD'; // Assuming this is the component for CRUD operations
import MapVisualizations from '/pages/MapVisualizations'; // Assuming this is the component for Map Visualizations

function Routing() {
    return (
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/about" element={<About />} />
        <Route path="/location" element={<LocationSearch />} />
        <Route path="/time" element={<TimeFrameSearch />} />
        <Route path="/advanced" element={<AdvancedSearch />} />
        <Route path="/crud" element={<CRUD />} />
        <Route path="/map" element={<MapVisualizations />} />
      </Routes>
    );
}

export default Routing;
