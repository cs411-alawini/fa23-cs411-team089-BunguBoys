import React from 'react'
import { useState } from "react";
import Routing from './Routing';
import { BrowserRouter, useLocation } from "react-router-dom";
import NavBar from '/components/NavBar';
import SideBar from '/components/SideBar';
import { ColorModeContext, useMode } from "../theme";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { Outlet } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';


import './App.css'

function App() {
  console.log("Rendering App...");
  const [theme, colorMode] = useMode();
  const [isSidebar, setIsSidebar] = useState(true);



  return (
    <ColorModeContext.Provider value={colorMode}>
    <ThemeProvider theme={theme}>
        <CssBaseline />
          <div className="app">
            <Toaster />
            <BrowserRouter>
            <SideBar isSidebar={isSidebar} />
            <main className="content">
              <NavBar setIsSidebar={setIsSidebar} />
                
                <Routing />
              
            </main>
            </BrowserRouter>
          </div>
    </ThemeProvider>
    </ColorModeContext.Provider>

  );
}

// PageContainer component
function PageContainer() {
  const location = useLocation();
  
  return (
    <div className="page-container">
      <div className="content-wrap">
        <div className="content"><Routing /></div>
      </div>
    </div>
  );
}

export default App;

